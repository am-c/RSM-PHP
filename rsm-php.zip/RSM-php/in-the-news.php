
<?php $title = 'In The News' ?>
<?php include("inc/header.php");?>

<?php include("inc/nav.php");?>
<div class="container-fluid pg-container">
                <h1>In The News</h1>
                  <iframe class="pg-frame" src="https://maps.arcgis.com/apps/MapTour/index.html?appid=4c35df611efe44fc8c36f7451387beea&embed"></iframe>
                    </div>
                    
                <?php include("inc/footer.php");?>

          
 
          <?php include("inc/footer-links.php");?>