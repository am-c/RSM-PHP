
<?php $title = 'Calendar' ?>
<?php include("inc/header.php");?>

<?php include("inc/nav.php");?>
<div class="container-fluid pg-container">
  <h1>Calendar</h1>
  <h3>Coming Soon!</h3>
  <a href="index.php"><i class="far fa-arrow-alt-circle-left"></i> Back to homepage</a>
</div>
          
<?php include("inc/footer.php");?>

<?php include("inc/footer-links.php");?>