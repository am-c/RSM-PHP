<div class="col-md-6 flex-off" style=" -ms-flex: unset !important; flex: unset !important; max-width: 100% !important;">
  <div class="sIcons">
    <a href="https://www.youtube.com/user/CORPSCONNECTION"><i class="fab fa-youtube"></i></a>
    <!-- <a href="http://usace.armylive.dodlive.mil"><i class="fas fa-blog"></i></a> -->
    <a href="https://twitter.com/USACEHQ"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.flickr.com/photos/usacehq"><i class="fab fa-flickr"></i></a>
    <a href="https://twitter.com/USACEHQ"><i class="fab fa-twitter"></i></a>
    <a href="https://www.army.mil"><img src="images/army.png" alt="United States Army" draggable="false"></a>
    <a href="https://www.usace.army.mil/Portals/2/docs/EEO/SHARP_Poster_2013.pdf"><img src="images/sharp-icon.png" alt="Sharp" draggable="false"></a>
    <a href="https://www.inscom.army.mil/isalute/"><img src="images/isalute-icon.png" alt="iSalute" draggable="false"></a>
  </div>
</div>
