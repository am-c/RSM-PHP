
<?php $title = 'RSM Mapper' ?>
<?php include("inc/header.php");?>

<?php include("inc/nav.php");?>
<div class="container-fluid pg-container">
  <h1>RSM Mapper</h1>
  <iframe class="pg-frame" src="https://maps.arcgis.com/apps/webappviewer/index.html?id=3d5cd625418c40119a5012d0d1d44b3e"></iframe>
</div>
<?php include("inc/footer.php");?>

<?php include("inc/footer-links.php");?>